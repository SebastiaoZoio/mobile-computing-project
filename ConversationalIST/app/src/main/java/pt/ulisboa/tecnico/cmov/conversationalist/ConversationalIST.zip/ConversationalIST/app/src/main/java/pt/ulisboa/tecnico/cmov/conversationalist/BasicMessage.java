package pt.ulisboa.tecnico.cmov.conversationalist;

import android.graphics.Bitmap;

import com.google.android.gms.maps.model.LatLng;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class BasicMessage {

    private String sender;
    private String content = null;
    private LocalDateTime time;
    private Bitmap image;
    private Boolean isImage = false;
    private LatLng coordinates;
    private boolean isMap = false;
    private int id = 0;

    public BasicMessage(String sender, String content, LocalDateTime time, int id) {
        this.sender = sender;
        this.content = content;
        this.time = time;
        this.id = id;
    }

    public BasicMessage(String sender, Bitmap image, LocalDateTime time, int id) {
        this.sender = sender;
        this.image = image;
        this.time = time;
        this.isImage = true;
        this.id = id;
    }

    public BasicMessage(String sender, LatLng coordinates, LocalDateTime time, int id){
        this.sender = sender;
        this.time = time;
        this.coordinates = coordinates;
        this.isMap = true;
        this.id = id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public Boolean isImage(){
        return this.isImage;
    }

    public LatLng getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(LatLng coordinates) {
        this.coordinates = coordinates;
    }

    public boolean isMap() {
        return isMap;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString()
    {
        return "Sender: " + this.getSender() + " - Content: " + this.getContent();
    }
}
